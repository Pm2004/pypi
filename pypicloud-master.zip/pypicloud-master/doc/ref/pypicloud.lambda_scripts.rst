pypicloud.lambda\_scripts module
================================

.. automodule:: pypicloud.lambda_scripts
   :members:
   :undoc-members:
   :show-inheritance:
