pypicloud.locator module
========================

.. automodule:: pypicloud.locator
   :members:
   :undoc-members:
   :show-inheritance:
