pypicloud.storage.azure\_blob module
====================================

.. automodule:: pypicloud.storage.azure_blob
   :members:
   :undoc-members:
   :show-inheritance:
