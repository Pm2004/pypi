pypicloud.views.simple module
=============================

.. automodule:: pypicloud.views.simple
   :members:
   :undoc-members:
   :show-inheritance:
