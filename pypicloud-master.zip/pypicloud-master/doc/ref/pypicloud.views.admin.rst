pypicloud.views.admin module
============================

.. automodule:: pypicloud.views.admin
   :members:
   :undoc-members:
   :show-inheritance:
