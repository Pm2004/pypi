pypicloud.storage.base module
=============================

.. automodule:: pypicloud.storage.base
   :members:
   :undoc-members:
   :show-inheritance:
